
import express from "express";
const app = express();
app.use(express.json());

app.post("/v1/aic/compute",(req,res)=>{
  const p=req.body;

  const R=(p.rating||0)*20;
  const E=Math.log10((p.user_ratings_total||1)+1)*30;
  const V=Math.sqrt(p.user_ratings_total||1)*2;

  const score=(R+E+V)/3;

  res.json({
    score: Math.round(score*10)/10,
    components:{R,E,V},
    multipliers:{confidence:0.9,stability:0.85},
    explain:{dominant:"reputation"}
  });
});

app.listen(4000,()=>console.log("AIC Engine running"));
