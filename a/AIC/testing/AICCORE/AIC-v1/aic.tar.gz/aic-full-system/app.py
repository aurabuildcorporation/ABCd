
import streamlit as st
import requests
import pandas as pd
import json

API="http://localhost:3000/v1/places/discover"

st.title("AIC Full Explorer")

query = st.text_input("Query")
lat = st.number_input("Lat",value=40.7)
lng = st.number_input("Lng",value=-74.0)

if st.button("Search"):
    params={"lat":lat,"lng":lng}
    if query:
        params["query"]=query

    data=requests.get(API,params=params).json()
    results=data["results"]

    df=pd.json_normalize(results)
    st.dataframe(df)

    st.download_button("Download JSON",json.dumps(results,indent=2))
    st.download_button("Download CSV",df.to_csv(index=False))
