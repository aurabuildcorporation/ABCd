
AIC FULL SYSTEM

Run backend:
node gateway.js
node aic-engine.js

Run UI:
streamlit run app.py
