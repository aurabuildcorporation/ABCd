
import express from "express";
import fetch from "node-fetch";
import sqlite3 from "sqlite3";
import { open } from "sqlite";

const app = express();
app.use(express.json());

let db;
(async () => {
  db = await open({ filename: "./aic.db", driver: sqlite3.Database });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT,
      entity_id TEXT,
      payload TEXT,
      timestamp INTEGER
    );
  `);
})();

async function emitEvent(type, entity_id, payload){
  await db.run(
    "INSERT INTO events (type, entity_id, payload, timestamp) VALUES (?,?,?,?)",
    [type, entity_id, JSON.stringify(payload), Date.now()]
  );
}

const AIC_URL = "http://localhost:4000/v1/aic/compute";

app.get("/v1/places/discover", async (req,res)=>{
  const { lat, lng, query, mint="false", usd=100 } = req.query;

  await emitEvent("REQUEST", "system", {lat,lng,query});

  let results = [];

  if(query){
    results = [
      { id:"q1", name: query+" Result A", lat, lng, rating:4.5, user_ratings_total:120 }
    ];
  } else {
    results = [
      { id:"p1", name:"Nearby Place A", lat, lng, rating:4.2, user_ratings_total:80 }
    ];
  }

  const enriched = await Promise.all(results.map(async p=>{
    const r = await fetch(AIC_URL,{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(p)
    }).then(r=>r.json());

    await emitEvent("AIC", p.id, r);

    let mint = null;
    if(mint==="true"){
      mint = { usd, pi: Number(usd)*1.2 };
      await emitEvent("MINT", p.id, mint);
    }

    return {...p, aic:r, mint};
  }));

  await emitEvent("DONE","system",{count:enriched.length});

  res.json({results:enriched});
});

app.get("/v1/events", async (req,res)=>{
  const rows = await db.all("SELECT * FROM events ORDER BY id DESC LIMIT 200");
  res.json(rows.map(r=>({...r,payload:JSON.parse(r.payload)})));
});

app.listen(3000, ()=>console.log("Gateway running"));
