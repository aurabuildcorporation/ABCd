
from pydantic import BaseModel

class Entity(BaseModel):
    id: str
    name: str
    industry: str
